


<?php $__env->startSection('title', 'Statistik'); ?>

<?php $__env->startSection('container'); ?>
    <div class="row">
      <div class="col-10">
        <h1>Nama : Gede Marta Hartawan</h1>
        <h1>NIM : 1915101056</h1>
      </div>
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Statistik\resources\views/index.blade.php ENDPATH**/ ?>