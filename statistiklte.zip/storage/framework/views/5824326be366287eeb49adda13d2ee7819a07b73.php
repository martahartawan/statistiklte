      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>
        <li><a href="/statistik"><i class="fa fa-book"></i> <span>Statistik</span></a></li>
       <?php /**PATH C:\statistiklte\resources\views/layout/nav.blade.php ENDPATH**/ ?>