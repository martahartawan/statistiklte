


<?php $__env->startSection('title', 'Statistik'); ?>

<?php $__env->startSection('container'); ?>
    <div class="row col-12">
        <form action="/statistik" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group mt-3">
            <label for="nama">Nama Mahasiswa:</label>
            <input type="text" class="form-control" placeholder="Masukan nama" name="nama" id="nama">
          </div>
          <div class="form-group">
            <label for="nilai">Nilai:</label>
            <input type="number" class="form-control" placeholder="Masukan nilai" name="nilai" id="nilai">
          </div>
          <button type="submit" class="btn btn-dark mt-3 mb-3">Add</button>
          <label for="min" class="ml-4">Nilai skor min : <b><?php echo e($min); ?></b></label>
          <label for="max" class="ml-4">Nilai skor max : <b><?php echo e($max); ?></b></label>
          <label for="rata2" class="ml-4">skor Rata-rata : <b><?php echo e($rata2); ?></b></label>
        </form> 
    </div>
  
<?php if(session('pesan')): ?>
    <div class="row">
      <div class="alert alert-success"><?php echo e(session('pesan')); ?></div>
    </div>
<?php endif; ?>
        
  <div class="row col-12">
    <table class="table table-bordered m-2">
      <div class=" bg-dark text-light text-center m-2">
        <h2>TABEL DATA MAHASISWA</h2>
      </div> 
      <thead>
        <tr>
          <th class="col-8">Nama</th>
          <th class="col-2">skor</th>
          <th class="col-2">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($data->nama_mahasiswa); ?></td>
            <td><?php echo e($data->nilai_mahasiswa); ?></td>
            <td>
              <a href="/statistik/edit/<?php echo e($data->id_mahasiswa); ?>" class="btn btn-sm btn-secondary">Edit</a>
              <a href="/statistik/delete/<?php echo e($data->id_mahasiswa); ?>" class="btn btn-sm btn-danger" id="delete">Delete</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>  
  </div>

  <div class="row">
      <div class="col-12 mr-auto">
          <div class="row">
              <div class="col-12 bg-white form-container">
                <div class="bg-dark text-light text-center">
                  <h2>TABEL FREKUENSI</h2>
                </div> 
                  <table class="table table-bordered">
                      <thead>
                          <tr>
                              <th class="col-8">Skor</th>
                              <th class="col-4">Frekuensi</th>
                          </tr>
                     </thead>
                     <tbody>
                         <?php $__currentLoopData = $frekuensi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nilai_mahasiswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         
                         <tr>
                             <td> <?php echo e($nilai_mahasiswa->nilai_mahasiswa); ?> </td>
                             <td> <?php echo e($nilai_mahasiswa->frekuensi); ?></td>
                          </tr>
                           
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                            <th>Total frekuensi :</th>
                            <td> <?php echo e($totalfrekuensi); ?></td>
                          </tr>
                          <tr>
                            <th>Total skor :</td>
                            <td> <?php echo e($totalskor); ?></td>
                          </tr>
                     </tbody>
                  </table>
              </div>
          </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Statistik\resources\views//statistik/index.blade.php ENDPATH**/ ?>