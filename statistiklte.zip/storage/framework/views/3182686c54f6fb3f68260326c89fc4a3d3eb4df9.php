


<?php $__env->startSection('title', 'Statistik'); ?>

<?php $__env->startSection('container'); ?>
  <div class="container bg-light mt-1">
    <div class="row col-12">
        <form action="/statistik" method="POST" enctype="multipart/form-data">
          <?php echo csrf_field(); ?>
          <div class="form-group mt-3">
            <label for="nama">Nama Mahasiswa:</label>
            <input type="text" class="form-control" placeholder="Masukan nama" name="nama" id="nama">
          </div>
          <div class="form-group">
            <label for="nilai">Nilai:</label>
            <input type="number" class="form-control" placeholder="Masukan nilai" name="nilai" id="nilai">
          </div>
          <button type="submit" class="btn btn-primary mt-3 mb-3">Add</button>
        </form> 
    </div>
  </div>
  

             

<?php if(session('pesan')): ?>
  <div class="container mt-3">
    <div class="row">
      <div class="alert alert-success"><?php echo e(session('pesan')); ?></div>
    </div>
  </div>
<?php endif; ?>
        
<div class="container mt-1 bg-light">     
  <div class="row col-12">
    <table class="table table-bordered m-2">
      <thead>
        <tr>
          <th>Nama</th>
          <th class="col-2">Nilai</th>
          <th class="col-2">Opsi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($data->nama_mahasiswa); ?></td>
            <td><?php echo e($data->nilai_mahasiswa); ?></td>
            <td>
              <a href="/statistik/edit/<?php echo e($data->id_mahasiswa); ?>" class="btn btn-sm btn-secondary">Edit</a>
              <a href="/statistik/delete/<?php echo e($data->id_mahasiswa); ?>" class="btn btn-sm btn-danger" id="delete">Delete</a>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>  
  </div>
</div>    

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\ProjectLaravel\Statistik\resources\views/statistik/index.blade.php ENDPATH**/ ?>