@extends('layout.template')
@section('content')
    <h1> Nama   : Gede Marta Hartawan</h1>
    <h1> Nim    : 1915101056</h1>
    <h1> Kelas  : Ilmu Komputer 4B</h1>
@endsection