
@extends('layout/main')

@section('title', 'Statistik')

@section('container')
    <div class="row">
      <div class="col-10">
        <h1>Nama : Gede Marta Hartawan</h1>
        <h1>NIM : 1915101056</h1>
      </div>
    </div> 
@endsection
